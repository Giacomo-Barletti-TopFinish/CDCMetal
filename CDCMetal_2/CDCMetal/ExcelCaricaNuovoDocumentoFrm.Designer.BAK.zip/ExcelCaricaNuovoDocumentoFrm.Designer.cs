﻿namespace CDCMetal
{
    partial class ExcelCaricaNuovoDocumentoFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ((System.ComponentModel.ISupportInitialize)(this._DS)).BeginInit();
            this.SuspendLayout();
            // 
            // ExcelCaricaNuovoDocumentoFrm
            // 
            this.ClientSize = new System.Drawing.Size(1105, 261);
            this.Name = "ExcelCaricaNuovoDocumentoFrm";
            this.Load += new System.EventHandler(this.ExcelCaricaNuovoDocumentoFrm_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this._DS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnApriFile;
        private System.Windows.Forms.Button btnCercaFile;
        private System.Windows.Forms.TextBox txtFilePath;
        private System.Windows.Forms.Label lblNumeroRigheExcel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblDataExcel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.DataGridView dgvExcelCaricato;
        private System.Windows.Forms.Button btnSalvaDB;
        private System.Windows.Forms.ComboBox ddlBrand;
        private System.Windows.Forms.Label label2;
    }
}